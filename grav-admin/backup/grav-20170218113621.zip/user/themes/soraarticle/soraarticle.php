<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class SoraArticle extends Theme
{

}
