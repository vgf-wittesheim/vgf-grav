<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Saturn extends Theme
{

}
