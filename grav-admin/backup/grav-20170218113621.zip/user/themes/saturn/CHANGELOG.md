# v1.6.0
## 01/09/2017

1. [](#improved)
    * Added `header.body_classes` support [https://github.com/getgrav/grav/issues/1240](https://github.com/getgrav/grav/issues/1240)

# v1.5.0
## 09/09/2016

1. [](#improved)
    * Update forms for the newest Form plugin markup

# v1.4.0
## 07/14/2016

1. [](#improved)
    * Remove unneeded streams from Theme YAML
    * Delete unused composer.json
    * Use https to load Google Fonts
1. [](#bugfix)
    * Fix setting the page language in the html tag
    * Fix pagination

# v1.3.0
## 01/06/2016

1. [](#new)
    * Add form nonce
1. [](#bugfix)
	* Fixed footnotes styling

# v1.2.0
## 10/29/2015

1. [](#new)
    * Transition from SimpleForm to core Forms & Email
    * Images replacement due to copyright infringement

# v1.1.0
## 09/18/2015

1. [](#new)
    * Improved compatibility with newest grav
    * Improved compatibility with SimpleForm plugin
    * Other minor fixes

# v1.0.0
## 09/04/2015

1. [](#new)
    * ChangeLog started...
